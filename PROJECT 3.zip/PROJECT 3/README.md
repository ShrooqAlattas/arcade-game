# Classic Arcade Game Clone Project
Most common usage of the word refers to games that forgo realism or complexity to deliver a more robust and fluid gameplay, mostly because thats what the original arcades were like.
You want an arcade you go to Mario Kart.

The original arcades are all typically highly responsive and easy to get into.

In this game we must not touch the worm and reach the top quickly

## Table of Contents

- [Instructions](#instructions)
- [Contributing](#contributing)

## Instructions



The folder contains three javascript folders The folder that runs the game is (app) contains the basic codes
There is also a pictures folder that contains the characters of the game you can change the player whenever you want to that just by replacing the path of the existing images with the player's personality

You only need to play to the keyboard and move the player and not touch the worm and then reach the top

## Contributing

This repository is the starter code for _all_ Udacity students. Therefore, we most likely will not accept pull requests.
