// Enemies our player must avoid
var Enemy = function(x,y,speed) {
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started
this.x=x;
this.y=y;
this.speed=speed;
    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
 this.sprite = 'images/enemy-bug.png';
 this.height=65;
 this.width=95;
};
//سرعة الدودات بين بعض 
const speed_bugs=-80
//مسافات التحرك حق اللاعب """الخطوات""" 
const line_horstal =91;
const line_vertcal=91;
// حساب النجوم 

var hart =document.querySelectorAll('.heart');

var hart2=3;
var collision_counter=0
//خاص بالوقت 
var second = 0;
var minutes=0;
let intervalId ;
var check_timer=true;
var m;
var s;

///////////////////section restaet///////// 
var restatrt;
restatrt=document.getElementById('restart');
restatrt.addEventListener('click',gameRestart);
function gameRestart(){document.location.reload();}
/////////////////////// 

// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
   //this.x =this.x+this.speed*dt;
   if (this.x > ctx.canvas.width +this.width){
    this.x=speed_bugs*Math.floor(Math.random()*4)+1;
}
else{
    // رقم (+180) سرعة التحرك الخاصة بالدودة  
    this.x=this.x+180*dt;
}
if(player.x<this.x+55
    &&player.y<this.y+55
    &&player.x+55>this.x
    &&55 +player.y>this.y){
        player.x=200;
        player.y=400;
        collision_counter++;
       // console.log(collision_counter);
    };
     /////////function timer///////// 
        
       
     function pad ( val ) { return val > 9 ? val : "0" + val; }
     if (check_timer){
     intervalId = setInterval( function()
         { 
             second++;
             if(second == 60){
                 minutes++;
                 second=0;
             }
            s= document.getElementById("seconds").innerHTML=pad(++second%60);
           m=  document.getElementById("minutes").innerHTML=pad(parseInt(second/60,10));
             
         }, 1000);
         check_timer = false;
     }

};

// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};
var Player =function(x,y,sprite){///-----
    this.x=x;
    this.y=y;
    this.sprite=sprite
    this.height=75;
    this.width=45;

}

Player.prototype.render=function(){
    ctx.drawImage(Resources.get(this.sprite),this.x,this.y);
}
Player.prototype.update=function(){

};


//تحركات اللاعب 
Player.prototype.handleInput=function(directtion){
    
if
(directtion=='left' && this.x-line_horstal>=0)
    {this.x=this.x-line_horstal;}
else if 
(directtion=='right' && this.x <382)
 {this.x=this.x+line_horstal;}
else if (directtion=='up'&& this.y -line_vertcal > 0 - player .height)

{this.y=this.y-line_vertcal;
}
else if (directtion =='down'&& this.y +line_vertcal < ctx.canvas.height-200)
{this.y=this.y+line_vertcal;}
 

//حالة الفوز 
if (collision_counter>=10)
{hart2=1}
else if (collision_counter>=7)
{hart2=2}
if (this.y<0){
    clearInterval(intervalId);
    this.x=200;
    this.y=400;
    alert("Congratulations  and your point  is "+hart2
    +"\n"  +"YOUR TIME IS minutes :"+m +"second"+s) 
}
}

/// Player.prototype.handleInput=function(){

// }
// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.


// Now instantiate your objects.
// Place all enemy objects in an array called allEnemies
// Place the player object in a variable called player





//انشاء الدودة وتحريكها 
const enemy_location=[50,150,200];
//عشان تمشي في المربعات
const allEnemies=enemy_location.map((y,index)=>{
return new Enemy(speed_bugs*(index+1),y);
});
//انشاء اللاعب من الكلاس 
const player=new Player (200,400,'images/char-pink-girl.png');

// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});

